#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <geometry_msgs/Twist.h>
#include <turtlesim/Spawn.h>

int main(int argc, char** argv){
  ros::init(argc, argv, "my_tf_listener");

  ros::NodeHandle node;

  ros::service::waitForService("spawn");  //应该是等待第一只乌龟启动完毕
  ros::ServiceClient add_turtle =
    node.serviceClient<turtlesim::Spawn>("spawn");
  turtlesim::Spawn srv;
  add_turtle.call(srv);  //每调用一次多一只乌龟在地图中，launch文件中使用<node pkg="turtlesim" type="turtlesim_node" name="sim"/>已经启动了一只
  add_turtle.call(srv);

  ros::Publisher turtle_vel =
    node.advertise<geometry_msgs::Twist>("turtle2/cmd_vel", 10);

  ros::Publisher turtle_vel1 =
    node.advertise<geometry_msgs::Twist>("turtle3/cmd_vel", 10);

  tf::TransformListener listener;

  ros::Rate rate(10.0);
  while (node.ok()){
    tf::StampedTransform transform;
    tf::StampedTransform transform32;
    try{
      listener.lookupTransform("/turtle2", "/carrot1",
                               ros::Time(0), transform);  //获得2到1的变换，也就是相对坐标
      listener.lookupTransform("/turtle3", "/turtle1",
                               ros::Time(0), transform32);  //获得3到2的变换
    }
    catch (tf::TransformException &ex) {
      ROS_ERROR("%s",ex.what());
      ros::Duration(1.0).sleep();
      continue;
    }

    geometry_msgs::Twist vel_msg;
    vel_msg.angular.z = 0.5 * atan2(transform.getOrigin().y(), transform.getOrigin().x());  //稳定后角速度会接近720°，因为时360的整数倍，所以不转了.但因为数据不会绝对的时720，所以会乱转
    vel_msg.linear.x = 0.5 * sqrt(pow(transform.getOrigin().x(), 2) +
                               pow(transform.getOrigin().y(), 2));
    turtle_vel.publish(vel_msg);

    vel_msg.angular.z = 4.0 * atan2(transform32.getOrigin().y(),
                                    transform32.getOrigin().x());
    vel_msg.linear.x = 0.5 * sqrt(pow(transform32.getOrigin().x(), 2) +
                                  pow(transform32.getOrigin().y(), 2));
    turtle_vel1.publish(vel_msg);

    rate.sleep();
  }
  return 0;
};


